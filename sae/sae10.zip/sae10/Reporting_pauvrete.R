library(shiny)
library(ggplot2)
library(plotly)
library(shinythemes)
library(DT)
library(dplyr)
library(tidyr)
library(fmsb)
library(RColorBrewer)
library(FactoMineR)
library(factoextra)

# Palette de couleur
ma_palette <- brewer.pal(5, "Reds")
# Importation des données et création des 2 df
data <- read.csv2(file="data.csv")
pauvrete_eleve <- data[order(data[,4],decreasing=T),]
data_sup <- head(pauvrete_eleve,5)
pauvrete_faible <-data[order(data[,4],decreasing=F),]
data_inf <- head(pauvrete_faible,5)

# Concatenation de plusieurs variables
data_infra_secteur_sup <- data_sup %>% select(libelle, admin_publique_enseignement_sante_2023, agriculture_2023, industrie_2023, construction_2023, commerces_transports_2023) %>% pivot_longer(cols = -libelle, names_to = "secteur", values_to = "valeur")
data_infra_secteur_inf <- data_inf %>% select(libelle, admin_publique_enseignement_sante_2023, agriculture_2023, industrie_2023, construction_2023, commerces_transports_2023) %>% pivot_longer(cols = -libelle, names_to = "secteur", values_to = "valeur")
data_infra_type_sup <- data_sup %>% select(libelle, gendarmerie_2024, banque_caisse_epargne_2024, grande_surface_2024) %>% pivot_longer(cols = -libelle, names_to = "type", values_to = "nombre")
data_infra_type_inf <- data_inf %>% select(libelle, gendarmerie_2024, banque_caisse_epargne_2024, grande_surface_2024) %>% pivot_longer(cols = -libelle, names_to = "type", values_to = "nombre")

# Préparation des données 
data_radar1_sup <- data_sup[, c("urgences_2024", "medecin_2024", "infirmier_2024", "pharmacie_2024")]
max_val_radar1_sup <- apply(data_radar1_sup, 2, max)
min_val_radar1_sup <- apply(data_radar1_sup, 2, min)
radar1_data_sup <- rbind(max_val_radar1_sup, min_val_radar1_sup, data_radar1_sup)
colnames(radar1_data_sup) <- c("Urgences", "Médecins", "Infirmiers", "Pharmacies")
data_radar1_inf <- data_inf[, c("urgences_2024", "medecin_2024", "infirmier_2024", "pharmacie_2024")]
max_val_radar1_inf <- apply(data_radar1_inf, 2, max)
min_val_radar1_inf <- apply(data_radar1_inf, 2, min)
radar1_data_inf <- rbind(max_val_radar1_inf, min_val_radar1_inf, data_radar1_inf)
colnames(radar1_data_inf) <- c("Urgences", "Médecins", "Infirmiers", "Pharmacies")

data_radar2_sup <- data_sup[, c("bassin_natation_2024", "gymnases_2024", "college_2024", "lycee_2024", "maternelle_primaire_2024")]
max_val_radar2_sup <- apply(data_radar2_sup, 2, max)
min_val_radar2_sup <- apply(data_radar2_sup, 2, min)
radar2_data_sup <- rbind(max_val_radar2_sup, min_val_radar2_sup, data_radar2_sup)
colnames(radar2_data_sup) <- c("Bassins natation", "Gymnases", "Collèges", "Lycées", "Maternelles/Primaires")
data_radar2_inf <- data_inf[, c("bassin_natation_2024", "gymnases_2024", "college_2024", "lycee_2024", "maternelle_primaire_2024")]
max_val_radar2_inf <- apply(data_radar2_inf, 2, max)
min_val_radar2_inf <- apply(data_radar2_inf, 2, min)
radar2_data_inf <- rbind(max_val_radar2_inf, min_val_radar2_inf, data_radar2_inf)
colnames(radar2_data_inf) <- c("Bassins natation", "Gymnases", "Collèges", "Lycées", "Maternelles/Primaires")

# Préparation de l'ACP
df_pca <- data[, 3:ncol(data)]
df_pca <- df_pca[, sapply(df_pca, is.numeric)]

# Calcul de ACP
rownames(df_pca) <- data$libelle
res.pca <- PCA(df_pca, scale.unit = TRUE, graph = FALSE)


intfce_util <- fluidPage(
  theme = shinytheme("journal"),
  
  navbarPage(title = "Analyse de la pauvreté",
             
             tabPanel(title = "Dashboard",
                      sidebarLayout(
                        sidebarPanel(
                          selectInput(inputId = "top5", label = "Plus grand taux de pauvreté ou moins grand ?", 
                                      choices = c("Top 5 plus gros taux !", "Top 5 plus petit taux !"), 
                                      selected = "Top 5 plus gros taux !")
                        ),
                        
                        mainPanel(
                          tabsetPanel(
                            tabPanel(title = "Accueil",
                                     h2("Découvrons la vue d'ensemble dans ces départements !"),
                                     fluidRow(
                                       column(6, plotOutput("graph_accueil_1")),
                                       column(6, plotOutput("graph_accueil_2"))
                                     ),
                                     hr(),
                                     fluidRow(
                                       column(6, plotOutput("graph_accueil_3")),
                                       column(6, plotOutput("graph_accueil_4"))
                                     )
                            ),
                            
                            tabPanel(title = "Logement",
                                     h2("Découvrons les habitations dans ces départements !"), 
                                     fluidRow(uiOutput("kpis_logement")),
                                     fluidRow(
                                       column(6, plotlyOutput("graph_maisons")),
                                       column(6, plotlyOutput("graph_imposes"))
                                     )
                            ),
                            
                            tabPanel(title = "Éducation",
                                     h2("Découvrons le niveau d'éducation dans ces départements !"), 
                                     fluidRow(column(12, plotOutput("graph_radar_edu"))),
                                     h4(uiOutput(outputId = "phrase")),
                                     h4(HTML("<br><br> Le niveau <b>CAP/BEP</b> semble <b>relativement stable</b> et <b>peu influencé par le taux de pauvreté</b>."))
                            ),
                            
                            tabPanel(title = "Infrastructures", 
                                     h2("Découvrons les infrastructures médicales, mais aussi scolaires et sportives de ces départements !"), 
                                     fluidRow(
                                       column(6, plotOutput("graph_infra_1")), 
                                       column(6, plotOutput("graph_infra_2"))
                                     ), 
                                     fluidRow(
                                       column(6, plotOutput("graph_infra_3")), 
                                       column(6, plotOutput("graph_infra_4"))
                                     )
                            )
                          )
                        )
                      ) 
             ),
             
             tabPanel(title = "Data",
                      DTOutput("data"),
                      h4(HTML("Vous pouvez consulter le tableau, rechercher ou trier selon une variable (Ex: Taux de pauvreté)"))
             ),
             
             tabPanel("Analyse Multifactorielle",
                      h2("Analyse en Composantes Principales (ACP)"),
                      fluidRow(
                        column(width = 6, 
                               h4("1. Importance des axes"),
                               plotOutput("plot_variance"),
                               p("En cumulant les deux premières composantes, nous conservons 64,8 % de l'information initiale")
                        ), # Virgule ajoutée ici
                        column(width = 6, 
                               h4("2. Liens entre les variables"),
                               plotOutput("plot_variables"),
                               p("Ce graphique illustre les corrélations : les variables pointant vers le haut (comme les prestations sociales) sont fortement liées au taux de pauvreté.")
                        ),
                      ),
                      fluidRow(
                        column(width = 12, 
                               h4("3. Profil socio-économique des départements"),
                               plotOutput("plot_individus", height = "700px"),
                               p("L axe verticale isole les départements les plus précaires en haut du graphique. ", "L'axe horizontal (Axe 1) oppose les zones rurales et industrielles (à gauche) aux zones urbaines denses et diplômées (à droite)."),
                               h5("L analyse montre que des départements de même densité urbaine s'opposent radicalement face à la pauvreté : les bassins d'emplois très qualifiés (Hauts-de-Seine, Yvelines) sont protégés par de hauts revenus, tandis que des territoires urbains ou historiques (Nord, Bouches-du-Rhône) subissent une forte précarité. Ainsi, la pauvreté rassemble des départements aux profils pourtant différents (comme le Nord très dense et l'Aisne plus rurale), qui se ressemblent ici par leur forte dépendance aux prestations sociales et l'absence de hauts revenus imposables")
                        )
                      )
             )
  )
)




serveur <- function(input, output, session) {
  
  # Accueil
  data_reactif <- reactive({
    if(input$top5 == "Top 5 plus gros taux !"){
      data_sup
    } else {
      data_inf
    }
  })
  output$graph_accueil_1 <- renderPlot({
    df_long <- data_reactif() %>%
      pivot_longer(cols = 5:7, names_to = "Tranche_Age", values_to = "Valeur") %>%
      group_by(Tranche_Age) %>%
      summarise(Valeur = mean(as.numeric(Valeur), na.rm = TRUE)) %>%
      mutate(Tranche_Age = case_when( grepl("0_24", Tranche_Age) ~ "0 à 24 ans", grepl("25_59", Tranche_Age) ~ "25 à 59 ans", grepl("60", Tranche_Age) ~ "60 ans et plus", TRUE ~ Tranche_Age))
    ggplot(df_long, aes(x = "", y = Valeur, fill = Tranche_Age)) + geom_bar(stat = "identity", width = 1) + coord_polar("y") + geom_text(aes(label = paste0(round(Valeur, 1), "%")), position = position_stack(vjust = 0.5)) + scale_fill_manual(values = ma_palette) + labs(title = "Moyenne des taux par tranche", fill = "Tranches d'âge") + theme_void()})
  
  output$graph_accueil_2 <- renderPlot({
    df <- data_reactif()
    col_dept <- names(df)[2]
    col_taux <- names(df)[8]
    ggplot(df, aes(x = .data[[col_dept]], y = .data[[col_taux]], fill = .data[[col_dept]])) + geom_col() + geom_text(aes(label = paste0(.data[[col_taux]], "%")), vjust = -0.3) + scale_fill_manual(values = ma_palette) + labs(title = "Pauvreté : Familles monoparentales", x = "Départements", y = "Taux (%)") + theme_minimal() + theme(legend.position = "none")})
  
  output$graph_accueil_3 <- renderPlot({
    df <- data_reactif()
    col_label <- names(df)[2]
    col_valeur <- names(df)[9]
    ggplot(df, aes(x = .data[[col_label]], y = .data[[col_valeur]], fill = .data[[col_label]])) + geom_col() + geom_text(aes(label = paste0(.data[[col_valeur]], "%")), vjust = -0.3) + scale_fill_manual(values = ma_palette) + labs(title = "Taux de pauvreté global", x = "Départements", y = "Taux (%)") + theme_minimal() + theme(legend.position = "none")})
  
  output$graph_accueil_4 <- renderPlot({
    df_plot <- data_reactif() %>%
      pivot_longer(cols = 22:24, names_to = "Type_Prestation", values_to = "Valeur") %>%
      group_by(Type_Prestation) %>%
      summarise(Valeur = mean(as.numeric(Valeur), na.rm = TRUE)) %>%
      mutate(Type_Prestation = case_when( grepl("RSA", Type_Prestation, ignore.case = TRUE) ~ "RSA", grepl("Prime", Type_Prestation, ignore.case = TRUE) ~ "Prime d'activité", grepl("familiales", Type_Prestation, ignore.case = TRUE) ~ "Prestations familiales", grepl("logement", Type_Prestation, ignore.case = TRUE) ~ "Prestations logements", grepl("sociales", Type_Prestation, ignore.case = TRUE) ~ "Prestations sociales", TRUE ~ Type_Prestation ))
    
    ggplot(df_plot, aes(x = "", y = Valeur, fill = Type_Prestation)) + geom_bar(stat = "identity", width = 1) + coord_polar("y") + geom_text(aes(label = paste0(round(Valeur, 1), "%")), position = position_stack(vjust = 0.5)) + scale_fill_manual(values = ma_palette) + labs(title = "Répartition moyenne des prestations", fill = "Prestations") + theme_void()})
  
  
  # Logement
  output$kpis_logement <- renderUI({
    df <- if(input$top5 == "Top 5 plus gros taux !") data_sup else data_inf
    moy_pauvrete <- round(mean(df$taux_pauvrete_2021, na.rm = TRUE), 1)
    moy_vacants <- round(mean(df$logements_vacants_2022, na.rm = TRUE), 1)
    moy_hlm <- round(mean(df$locataires_HLM_2022, na.rm = TRUE), 1)
    tagList(
      div(style = "display: flex; justify-content: space-between; gap: 20px; margin-bottom: 20px; padding: 0 15px;",
      # KPI 1
      div(style = paste0("flex: 1; background-color: ", ma_palette[5], "; color: white; text-align: center; border-radius: 10px; padding: 15px; box-shadow: 2px 2px 5px rgba(0,0,0,0);"),
              h4("Pauvreté moyenne", style = "margin-top: 0; font-size: 16px; opacity: 0.8;"),
              h2(paste0(moy_pauvrete, " %"), style = "font-weight: bold; margin-bottom: 0;")),
      # KPI 2
      div(style = paste0("flex: 1; background-color: ", ma_palette[4], "; color: white; text-align: center; border-radius: 10px; padding: 15px; box-shadow: 2px 2px 5px rgba(0,0,0,0);"),
              h4("Logements vacants (moyenne)", style = "margin-top: 0; font-size: 16px; opacity: 0.8;"),
              h2(paste0(moy_vacants, " %"), style = "font-weight: bold; margin-bottom: 0;")),
      # KPI 3
      div(style = paste0("flex: 1; background-color: ", ma_palette[3], "; color: white; text-align: center; border-radius: 10px; padding: 15px; box-shadow: 2px 2px 5px rgba(0,0,0,0);"),
              h4("Locataires HLM (moyenne)", style = "margin-top: 0; font-size: 16px; opacity: 0.8;"),
              h2(paste0(moy_hlm, " %"), style = "font-weight: bold; margin-bottom: 0;")
          )
      )
    )
  })
  
  output$graph_maisons <- renderPlotly({
    df <- if(input$top5 == "Top 5 plus gros taux !") data_sup else data_inf
    p <- plot_ly(df, x = ~libelle, y = ~maisons_2022, type = 'bar', name = 'Maisons', marker = list(color = ma_palette[4])) %>%
      add_trace(y = ~appartements_2022, name = 'Appartements', marker = list(color = ma_palette[2])) %>%
      layout(title = "Typologie : Maisons vs Appartements", 
             yaxis = list(title = "% du parc", range = c(0, 100)),
             barmode = 'group', xaxis = list(title = ""))
    p
  })
  
  output$graph_imposes <- renderPlotly({
    df <- if(input$top5 == "Top 5 plus gros taux !") data_sup else data_inf
    p <- ggplot(df, aes(x = reorder(libelle, -menages_fiscaux_imposes_2021), y = menages_fiscaux_imposes_2021, fill = libelle)) +
      geom_col() + 
      coord_cartesian(ylim = c(0, 100)) +
      labs(title = "Ménages fiscaux imposés (2021)", x = "", y = "%") +
      theme_minimal() +
      scale_fill_manual(values = ma_palette) # On applique la palette ici
    ggplotly(p) %>% layout(showlegend = FALSE)
  })
  
  
  # Éducation
  output$graph_radar_edu <- renderPlot({
    df <- if(input$top5 == "Top 5 plus gros taux !") data_sup else data_inf
    df_edu <- df[, c("pop_non_diplomes_2022", "pop_bepc_brevet_2022", "pop_cap_bep_2022", "pop_bac_2022", "pop_bac.2_2022", "pop_bac.3_.4_2022", "pop_bac.5_2024")]
    colnames(df_edu) <- c("Sans diplôme", "Brevet", "CAP/BEP", "Bac", "Bac+2", "Bac+3/4", "Bac+5")
    plafond_dynamique <- max(df_edu, na.rm = TRUE) * 1.1 
    max_val <- rep(plafond_dynamique, 7)
    min_val <- rep(0, 7)
    df_radar <- rbind(max_val, min_val, df_edu)
    couleurs_bords <- c("#E74C3C", "#3498DB", "#2ECC71", "#F1C40F", "#9B59B6")
    couleurs_remplissage <- c(rgb(0.9,0.3,0.2,0.2), rgb(0.2,0.6,0.8,0.2), rgb(0.1,0.8,0.4,0.2), rgb(0.9,0.7,0.1,0.2), rgb(0.6,0.3,0.7,0.2))
    graduations <- round(seq(0, plafond_dynamique, length.out = 5), 1)
    radarchart(df_radar, axistype = 1, caxislabels = graduations, axislabcol = "black", pcol = couleurs_bords, pfcol = couleurs_remplissage, plwd = 2, cglcol = "grey", cglty = 1, cglwd = 0.8, vlcex = 1.1, title = "Profil éducatif par département (%)")
    legend(x = "bottom", legend = df$libelle, bty = "n", pch = 20, col = couleurs_bords, pt.cex = 2, horiz = TRUE)})
  
  
  # Infrastructures
  output$graph_infra_1 <- renderPlot({
    if(input$top5 == "Top 5 plus gros taux !") {
      ggplot(data_infra_secteur_sup, aes(x = libelle, y = valeur, fill = secteur)) + geom_col() + theme_minimal() + labs(title = "Répartition des effectifs par secteur", x = "Département", y = "Part des effectifs", fill = "Secteur") + theme(plot.title = element_text(size = 15, face = "bold")) + scale_fill_manual(values = ma_palette, labels = c("Administration publique", "Agriculture", "Industrie", "Construction", "Commerce et transport"))}
    else {
      ggplot(data_infra_secteur_inf, aes(x = libelle, y = valeur, fill = secteur)) + geom_col() + theme_minimal() + labs(title = "Répartition des effectifs par secteur", x = "Département", y = "Part des effectifs", fill = "Secteur") + theme(plot.title = element_text(size = 15, face = "bold")) + scale_fill_manual(values = ma_palette, labels = c("Administration publique", "Agriculture", "Industrie", "Construction", "Commerce et transport"))}
  })
  
  output$graph_infra_2 <- renderPlot({
    if(input$top5 == "Top 5 plus gros taux !") {
      radarchart(radar1_data_sup, title = "Effectifs de santé par département (2024)", cex.main = 1.25)}
    else {
      radarchart(radar1_data_inf, title = "Effectifs de santé par département (2024)", cex.main = 1.25)}
  })  
  
  output$graph_infra_3 <- renderPlot({
    if(input$top5 == "Top 5 plus gros taux !") {
      radarchart(radar2_data_sup, title = "Infrastructures scolaires et sportives par département (2024)", cex.main = 1.25)}
    else {
      radarchart(radar2_data_inf, title = "Infrastructures scolaires et sportives par département (2024)", cex.main = 1.25)}
  })
  
  output$graph_infra_4 <- renderPlot({
    if(input$top5 == "Top 5 plus gros taux !") {
      ggplot(data_infra_type_sup, aes(x = libelle, y = nombre, fill = type)) + geom_col(position = "dodge") + theme_minimal() + labs( title = "Comparaison des équipements par département (2024)", x = "Département", y = "Nombre", fill = "Type d'équipement") + theme(plot.title = element_text(size = 15, face = "bold")) + scale_fill_manual(values = ma_palette, labels = c("Gendarmerie", "Banque et caisse d’épargne", "Grande surface"))}
    else {
      ggplot(data_infra_type_inf, aes(x = libelle, y = nombre, fill = type)) + geom_col(position = "dodge") + theme_minimal() + labs( title = "Comparaison des équipements par département (2024)", x = "Département", y = "Nombre", fill = "Type d'équipement") + theme(plot.title = element_text(size = 15, face = "bold")) + scale_fill_manual(values = ma_palette, labels = c("Gendarmerie", "Banque et caisse d’épargne", "Grande surface"))}
  })
  
  output$phrase <- renderUI({
    if(input$top5 == "Top 5 plus gros taux !") {
      h4(HTML("Grâce à ce graphique, nous pouvons observer que dans les <b>départements avec un fort taux de pauvreté</b>, les résidents sont majoritairement <b>peu diplômés</b> : beaucoup n'ont <b>aucun diplôme</b> ou seulement un <b>CAP/BEP</b>.<br><br> À l’inverse, les niveaux <b>bac+3</b> et surtout <b>bac+5</b> sont <b>très peu représentés</b> dans ces territoires."))}
    else {
      h4(HTML("Dans les <b>départements avec un faible taux de pauvreté</b>, la situation est différente : on observe <b>moins de personnes sans diplôme</b> et une proportion <b>beaucoup plus importante de diplômés bac+5</b>."))}
    })
  
  
  #Table
  output$data <- renderDT({
    datatable(data)
  })

  
  # Graphiques ACP
  output$plot_variance <- renderPlot({
    fviz_eig(res.pca, addlabels = TRUE, ylim = c(0, 50))
  })
  
  output$plot_variables <- renderPlot({
    fviz_pca_var(res.pca, 
                 col.var = "contrib", 
                 gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
                 repel = TRUE,
                 select.var = list(contrib = 15)
    )
  })
  
  output$plot_individus <- renderPlot({
    fviz_pca_ind(res.pca,
                 col.ind = "cos2", 
                 gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
                 repel = TRUE,
                 title = "",
                 select.ind = list(cos2 = 40)
    )
  })
  
  
}


shinyApp(ui = intfce_util, server = serveur)

